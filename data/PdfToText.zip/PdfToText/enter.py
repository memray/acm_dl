# -*- coding: utf-8
from utils import pdftohtml, pdftohtmlDirectory, htmltotext, saveText
import sys
reload(sys)
sys.setdefaultencoding('utf-8')


if __name__ == '__main__':
    # 处理单个pdf
    # 存放需要处理的单个pdf路径
    # filepath = 'Sample/P13.pdf'
    # htmlpathList = []
    # pdftohtml(filepath, htmlpathList)
    # for htmlpath in htmlpathList:
    #     print htmlpath
    #     saveText(htmltotext(htmlpath), htmlpath)

    # 处理目录
    # 存放需要处理的pdf的目录路径
    directoryPath = 'C:/Users/Roger/Desktop/Memary/files'
    htmlpathList = []
    print '--------------start to handle------------'
    pdftohtmlDirectory(directoryPath, htmlpathList)
    print '--------------save all text--------------'
    for htmlpath in htmlpathList:
        print htmlpath
        saveText(htmltotext(htmlpath), htmlpath)

        
    
    
